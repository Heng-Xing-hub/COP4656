package com.example.teamproject;

import android.os.Parcel;
import android.os.Parcelable;

public class Item implements Parcelable
{
    private String name;
    private String imageURL;
    private String description;
    private int price;
    private int quantity;

    public Item(String name, int quantity, int price, String imageURL, String description)
    {
        this.name = name;
        this.price = price;
        this.imageURL = imageURL;
        this.description = description;
        this.quantity = quantity;
    }

    public String getName()
    {
        return this.name;
    }
    public String getImageURL()
    {
        return this.imageURL;
    }
    public String getDescription()
    {
        return this.description;
    }
    public int getPrice()
    {
        return this.price * this.quantity;
    }
    public int getQuantity()
    {
        return this.quantity;
    }
    public void setQuantity(int value)
    {
        this.quantity = value;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(description);
        parcel.writeString(imageURL);
        parcel.writeInt(quantity);
        parcel.writeInt(price);
    }

    public Item(Parcel in) {
        name = in.readString();
        description = in.readString();
        imageURL = in.readString();
        quantity = in.readInt();
        price = in.readInt();
    }

    public static final Creator<Item> CREATOR = new Creator<Item>() {
        public Item createFromParcel(Parcel in) {
            return new Item(in);
        }

        public Item[] newArray(int size) {
            return new Item[size];
        }
    };
}
