package com.example.teamproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.util.ArrayList;

public class cartActivity extends AppCompatActivity {

    ListView listView;
    public ArrayList<Item> cart = new ArrayList<Item>();
    public ArrayList<String> scart = new ArrayList<String>();

    TextView title;
    TextView title1;
    TextView title2;
    Button check;
    Cursor mCursor;
    float price1 =0;
    float price2 =0;

    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        title = (TextView)findViewById(R.id.subTotal);
        title1 = (TextView)findViewById(R.id.Tax);
        title2 = (TextView)findViewById(R.id.priceSummary);


        listView = (ListView)findViewById(R.id.ListView);


        // restore cart data from bundle if applicable
        Bundle b = getIntent().getExtras();
        if (b != null && !b.isEmpty()) {
            //Toast.makeText(cartActivity.this, "imported bundle into cart!", Toast.LENGTH_LONG);
            ArrayList<Item> pcart = b.getParcelableArrayList("shopping_cart");
            if (pcart != null) {
                cart = pcart;
                for (int i = 0; i < cart.size(); i++) {
                    String name = cart.get(i).getName();
                    int quantity = cart.get(i).getQuantity();
                    float price = cart.get(i).getPrice();
                    price /= 100;
                    price1 = price1 + price;

                    String s = String.format("%s (x %d) $%.2f", name, quantity, price);
                    scart.add(s);
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, scart);
                listView.setAdapter(adapter);
            }
        }


        // to set the check button from content provider

        check = (Button)findViewById(R.id.button);

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                clear();

                Uri mNewUri;
                float sub = 0;
                float subTotal = 0;
                float Tax = 0;
                double Total;
                ContentValues mNewValues = new ContentValues();

                //calculate the total price
               /*if(cart != null) {
                   for (int i = 0; i < cart.size(); i++) {
                       sub = cart.get(i).getPrice();
                       sub /= 100;
                       subTotal = +sub;
                   }*/
                   subTotal = price1;
                   Tax = (float) (price1 *0.07);
                   Total = price1 * 1.07;

                   String a = String.format("%.2f", subTotal);
                   String b = String.format("%.2f", Tax);
                   String c = String.format("%.2f", Total);

                   mNewValues.put(MyContentProvider.COLUMN_SUBTOTAL, "Subtotal: "+ a + "\n");
                   mNewValues.put(MyContentProvider.COLUMN_TAX, "TAX : "+ b + "\n" );
                   mNewValues.put(MyContentProvider.COLUMN_TOTAL, "Total: " + c + "\n");



                ContentResolver cr = getContentResolver();
                cr.delete(MyContentProvider.CONTENT_URI, null, null);

                mNewUri = getContentResolver().insert(
                        MyContentProvider.CONTENT_URI, mNewValues);

                mCursor = null;

                mCursor = getContentResolver().query(MyContentProvider.CONTENT_URI, null, null, null, null);

                if (mCursor != null) {
                    if (mCursor.getCount() > 0) {
                        mCursor.moveToNext();
                        title.setText(mCursor.getString(1));
                        title1.setText(mCursor.getString(2));
                        title2.setText(mCursor.getString(3));
                    }
                }


            }
        });


    }

    public void returnToMain(View view)
    {
        // create a new MainActivity -- and pass the list in as a bundle
        Intent intent = new Intent(cartActivity.this, MainActivity.class);
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("shopping_cart", cart);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    private void clear() {
        title.setText("");
        title1.setText("");
        title2.setText("");

        mCursor = null;
    }




}

