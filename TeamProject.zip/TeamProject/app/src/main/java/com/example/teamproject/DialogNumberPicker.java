package com.example.teamproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;

public class DialogNumberPicker extends Activity implements NumberPicker.OnValueChangeListener
{
    private static TextView tv;
    static Dialog d ;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        show();
    }
    @Override
    public void onValueChange(NumberPicker picker, int oldVal, int newVal) {

        Log.i("value is",""+newVal);

    }

    public void show()
    {
        /*
        source: https://stackoverflow.com/questions/17805040/how-to-create-a-number-picker-dialog

         */
        final Dialog d = new Dialog(DialogNumberPicker.this);
        d.setTitle("How many would you like to purchase?");
        d.setContentView(R.layout.dialog);
        Button b1 = (Button) d.findViewById(R.id.button_set);
        Button b2 = (Button) d.findViewById(R.id.button_cancel);
        final NumberPicker np = (NumberPicker) d.findViewById(R.id.numberPicker1);
        np.setMaxValue(99);
        np.setMinValue(0);
        np.setWrapSelectorWheel(false);
        np.setOnValueChangedListener(this);
        // set button
        b1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                int selectedValue = np.getValue();
                // TODO: return the selectedValue and add item to cart

                d.dismiss();
            }
        });
        // cancel button
        b2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        d.show();
    }
}