package com.example.teamproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class cartActivity extends AppCompatActivity {

    ListView listView;
    TextView title;
    TextView title1;
    TextView title2;
    public List<Item> cart = new ArrayList<Item>();

    Button check;
    Cursor mCursor;

    class Item
    {
        private String name;
        private String imageURL;
        private String description;
        private int price;
        private int quantity;

        public Item(String name, int quantity, int price, String imageURL, String description)
        {
            this.name = name;
            this.price = price;
            this.imageURL = imageURL;
            this.description = description;
            this.quantity = quantity;
        }

        public String getName()
        {
            return this.name;
        }
        public String getImageURL()
        {
            return this.imageURL;
        }
        public int getPrice()
        {
            return this.price * this.quantity;
        }
        public String getDescription()
        {
            return this.description;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);


        title = (TextView)findViewById(R.id.textView22);
        title1 = (TextView)findViewById(R.id.textView23);
        title2 = (TextView)findViewById(R.id.textView24);

        listView = (ListView)findViewById(R.id.ListView);

        check = (Button)findViewById(R.id.button);

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri mNewUri;

                ContentValues mNewValues = new ContentValues();
                mNewValues.put(MyContentProvider.COLUMN_SUBTOTAL, "Subtotal: 10 \n");
                mNewValues.put(MyContentProvider.COLUMN_TAX, "TAX : 1 \n");
                mNewValues.put(MyContentProvider.COLUMN_TOTAL, "Total: 11 \n");


                mNewUri = getContentResolver().insert(
                        MyContentProvider.CONTENT_URI, mNewValues);

                mCursor = null;

                mCursor = getContentResolver().query(MyContentProvider.CONTENT_URI, null, null, null, null);

                if (mCursor != null) {
                    if (mCursor.getCount() > 0) {
                        mCursor.moveToNext();
                        title.setText(mCursor.getString(1));
                        title1.setText(mCursor.getString(2));
                        title2.setText(mCursor.getString(3));
                    }
                }


            }
        });




    }
}