package com.example.teamproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.util.ArrayList;

public class cartActivity extends AppCompatActivity {

    ListView listView;
    public ArrayList<Item> cart = new ArrayList<Item>();
    public ArrayList<String> scart = new ArrayList<String>();

    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        listView = (ListView)findViewById(R.id.ListView);


        // restore cart data from bundle if applicable
        Bundle b = getIntent().getExtras();
        if (b != null && !b.isEmpty()) {
            //Toast.makeText(cartActivity.this, "imported bundle into cart!", Toast.LENGTH_LONG);
            ArrayList<Item> pcart = b.getParcelableArrayList("shopping_cart");
            if (pcart != null) {
                cart = pcart;
                for (int i = 0; i < cart.size(); i++) {
                    String name = cart.get(i).getName();
                    int quantity = cart.get(i).getQuantity();
                    float price = cart.get(i).getPrice();
                    price /= 100;
                    String s = String.format("%s (x %d) $%.2f", name, quantity, price);
                    scart.add(s);
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, scart);
                listView.setAdapter(adapter);
            }
        }

    }

    public void returnToMain(View view)
    {
        // create a new MainActivity -- and pass the list in as a bundle
        Intent intent = new Intent(cartActivity.this, MainActivity.class);
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("shopping_cart", cart);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}