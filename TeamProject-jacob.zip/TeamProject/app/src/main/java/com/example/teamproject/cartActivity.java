package com.example.teamproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class cartActivity extends AppCompatActivity {

    ListView listView;
    public ArrayList<Item> cart = new ArrayList<Item>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        listView = (ListView)findViewById(R.id.ListView);


        // restore cart data from bundle if applicable
        Bundle b = getIntent().getExtras();
        if (b != null && !b.isEmpty()) {
            Toast.makeText(cartActivity.this, "imported bundle into cart!", Toast.LENGTH_LONG);
            ArrayList<Item> pcart = b.getParcelableArrayList("shopping_cart");
            if (pcart != null)
                cart = pcart;
        }

    }

    public void returnToMain(View view)
    {
        // create a new MainActivity -- and pass the list in as a bundle
        Intent intent = new Intent(cartActivity.this, MainActivity.class);
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("shopping_cart", cart);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}