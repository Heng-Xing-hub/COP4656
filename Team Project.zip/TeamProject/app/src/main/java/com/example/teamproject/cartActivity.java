package com.example.teamproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class cartActivity extends AppCompatActivity {

    ListView listView;
    TextView title;
    public List<Item> cart = new ArrayList<Item>();

    class Item
    {
        private String name;
        private String imageURL;
        private String description;
        private int price;
        private int quantity;

        public Item(String name, int quantity, int price, String imageURL, String description)
        {
            this.name = name;
            this.price = price;
            this.imageURL = imageURL;
            this.description = description;
            this.quantity = quantity;
        }

        public String getName()
        {
            return this.name;
        }
        public String getImageURL()
        {
            return this.imageURL;
        }
        public int getPrice()
        {
            return this.price * this.quantity;
        }
        public String getDescription()
        {
            return this.description;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);


        title = (TextView)findViewById(R.id.textView22);

        listView = (ListView)findViewById(R.id.ListView);

        Intent i = getIntent();
        cart = (List<Item>) i.getSerializableExtra("LIST");

        title.setText(cart.get(0).name);




    }
}